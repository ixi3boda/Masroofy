// The backend's chart API (see the backend README, "Charts").

export type Category = 'stock' | 'gold' | 'silver' | 'fx';
export type RangeCode = '1D' | '1W' | '1M' | '6M' | '1Y';
export type Side = 'buy' | 'sell';

/** One point: Cairo time ("2026-11-26T10:15:00", midnight for daily prices) and the value. */
export interface ChartPoint {
  t: string;
  v: number;
}

/** The answer of GET /api/chart. `change` is measured from `baseline`. */
export interface ChartData {
  type: Category;
  symbol: string;
  range: RangeCode;
  label: string;
  unit: string;
  intraday: boolean;
  points: ChartPoint[];
  baseline: number | null;
  last: number | null;
  change: number | null;
  changePercent: number | null;
  min: number | null;
  max: number | null;
}

export type Symbols = Record<Category, string[]>;

/** The backend's address. Empty = the same server that serves this page (or the dev proxy). */
const BASE: string = import.meta.env.VITE_API_URL ?? '';

async function get<T>(path: string, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await fetch(BASE + path, { signal, headers: { Accept: 'application/json' } });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e;
    throw new Error('Could not reach the server. Is the backend running?');
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`The server answered ${res.status}${text ? ': ' + text.slice(0, 160) : ''}`);
  }
  return (await res.json()) as T;
}

export function getSymbols(signal?: AbortSignal): Promise<Symbols> {
  return get<Symbols>('/api/chart/symbols', signal);
}

export function getChart(
  type: Category,
  symbol: string,
  range: RangeCode,
  side: Side,
  signal?: AbortSignal,
): Promise<ChartData> {
  const q = new URLSearchParams({ type, symbol, range, side });
  return get<ChartData>(`/api/chart?${q}`, signal);
}
