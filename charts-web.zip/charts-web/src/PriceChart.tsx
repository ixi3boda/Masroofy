import { Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { ChartData } from './api';
import { axisTime, formatValue } from './format';

interface TickProps {
  x: number;
  y: number;
  payload: { value: number };
}

interface Props {
  chart: ChartData;
  color: string;
  /** Called with the index of the point under the mouse or finger, or null when it leaves. */
  onActive: (index: number | null) => void;
}

/**
 * The line chart: soft fill under the line, price labels on the right, time labels under it, and a
 * dashed line at yesterday's price on the Day chart. Hover (or touch and drag) to pick a point.
 */
export function PriceChart({ chart, color, onActive }: Props) {
  const data = chart.points.map((p, i) => ({ i, v: p.v }));
  const last = data.length - 1;
  const ticks = Array.from(new Set([0, Math.floor(last / 2), last]));
  const gradientId = `fill-${chart.type}-${chart.symbol}-${chart.range}`.replace(/[^\w-]/g, '');
  const showBaseline = chart.intraday && chart.baseline !== null;

  // Keep the baseline inside the chart, and add a little room above and below the line.
  const values = data.map((d) => d.v).concat(showBaseline ? [chart.baseline as number] : []);
  let lo = Math.min(...values);
  let hi = Math.max(...values);
  if (hi - lo < 1e-9) {
    lo -= 1;
    hi += 1;
  }
  const pad = (hi - lo) * 0.08;

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={data}
        margin={{ top: 8, right: 0, bottom: 0, left: 0 }}
        onMouseMove={(s) => onActive(s && s.isTooltipActive && typeof s.activeTooltipIndex === 'number' ? s.activeTooltipIndex : null)}
        onMouseLeave={() => onActive(null)}
      >
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.28} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke="var(--grid)" />
        <XAxis
          dataKey="i"
          type="number"
          domain={[0, Math.max(last, 1)]}
          ticks={ticks}
          tick={(props: TickProps) => {
            const i = props.payload.value;
            // First label starts at the left edge, last one ends at the right edge, so none is cut off.
            const anchor = i === 0 ? 'start' : i === last ? 'end' : 'middle';
            return (
              <text x={props.x} y={props.y + 12} textAnchor={anchor} fill="var(--muted)" fontSize={12}>
                {chart.points[i] ? axisTime(chart.points[i], chart) : ''}
              </text>
            );
          }}
          tickLine={false}
          axisLine={false}
          interval={0}
          padding={{ left: 0, right: 0 }}
        />
        <YAxis
          orientation="right"
          domain={[lo - pad, hi + pad]}
          ticks={[lo, (lo + hi) / 2, hi]}
          tickFormatter={(v: number) => formatValue(v)}
          tick={{ fill: 'var(--muted)', fontSize: 12 }}
          tickLine={false}
          axisLine={false}
          width={78}
        />
        {showBaseline && (
          <ReferenceLine y={chart.baseline as number} stroke="var(--muted)" strokeDasharray="6 5" ifOverflow="extendDomain" />
        )}
        <Tooltip content={() => null} cursor={{ stroke: 'var(--muted)', strokeWidth: 1 }} isAnimationActive={false} />
        <Area
          type="linear"
          dataKey="v"
          stroke={color}
          strokeWidth={2}
          fill={`url(#${gradientId})`}
          dot={data.length === 1 ? { r: 4, fill: color } : false}
          activeDot={{ r: 5, fill: color, stroke: 'var(--bg)', strokeWidth: 2 }}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
