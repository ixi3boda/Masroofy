import { useEffect, useRef, useState } from 'react';
import { getChart, getSymbols } from './api';
import type { Category, ChartData, RangeCode, Side, Symbols } from './api';
import { PriceChart } from './PriceChart';
import { formatValue, pointTime, signed, sinceText, sourceText, symbolTitle } from './format';

const CATEGORIES: { id: Category; title: string }[] = [
  { id: 'stock', title: 'Stocks' },
  { id: 'gold', title: 'Gold' },
  { id: 'silver', title: 'Silver' },
  { id: 'fx', title: 'Currency' },
];

const RANGES: { id: RangeCode; title: string }[] = [
  { id: '1D', title: 'Day' },
  { id: '1W', title: 'Week' },
  { id: '1M', title: 'Month' },
  { id: '6M', title: '6M' },
  { id: '1Y', title: 'Year' },
];

function changeColor(change: number | null | undefined): string {
  if (!change) return 'var(--flat)';
  return change > 0 ? 'var(--up)' : 'var(--down)';
}

/** The charts page: tabs (Stocks, Gold, Silver, Currency), symbols, the chart and the range buttons. */
export function App() {
  const [symbols, setSymbols] = useState<Symbols | null>(null);
  const [category, setCategory] = useState<Category>('stock');
  const [chosen, setChosen] = useState<Partial<Record<Category, string>>>({});
  const [range, setRange] = useState<RangeCode>('1M');
  const [side, setSide] = useState<Side>('sell');
  const [chart, setChart] = useState<ChartData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState<number | null>(null);
  const [reload, setReload] = useState(0);

  const list = symbols?.[category] ?? [];
  const symbol = chosen[category] ?? list[0];

  // The list of symbols, once (and again after Retry).
  useEffect(() => {
    const ctl = new AbortController();
    setError(null);
    getSymbols(ctl.signal)
      .then(setSymbols)
      .catch((e: Error) => {
        if (e.name !== 'AbortError') {
          setError(e.message);
          setLoading(false);
        }
      });
    return () => ctl.abort();
  }, [reload]);

  // The chart, whenever what is selected changes. An older answer never replaces a newer one.
  const latest = useRef(0);
  useEffect(() => {
    if (!symbols) return;
    if (!symbol) {
      setChart(null);
      setLoading(false);
      return;
    }
    const ctl = new AbortController();
    const id = ++latest.current;
    setLoading(true);
    setError(null);
    getChart(category, symbol, range, side, ctl.signal)
      .then((c) => {
        if (id === latest.current) {
          setChart(c);
          setActive(null);
        }
      })
      .catch((e: Error) => {
        if (e.name !== 'AbortError' && id === latest.current) setError(e.message);
      })
      .finally(() => {
        if (id === latest.current) setLoading(false);
      });
    return () => ctl.abort();
  }, [symbols, category, symbol, range, side, reload]);

  const shown = chart && chart.type === category ? chart : null;
  const point = shown && shown.points.length > 0 ? shown.points[active ?? shown.points.length - 1] : null;
  const base = shown?.baseline ?? null;
  const change = point && base !== null ? point.v - base : null;
  const pct = change !== null && base ? (change / base) * 100 : null;

  return (
    <main className="app">
      <nav className="tabs" role="tablist">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            role="tab"
            aria-selected={c.id === category}
            className={c.id === category ? 'tab selected' : 'tab'}
            onClick={() => {
              setCategory(c.id);
              setActive(null);
            }}
          >
            {c.title}
          </button>
        ))}
      </nav>

      <div className="chips">
        {list.map((s) => (
          <button
            key={s}
            className={s === symbol ? 'chip selected' : 'chip'}
            onClick={() => setChosen((m) => ({ ...m, [category]: s }))}
          >
            {symbolTitle(category, s)}
          </button>
        ))}
        {category === 'fx' && (
          <span className="side">
            {(['buy', 'sell'] as Side[]).map((s) => (
              <button key={s} className={s === side ? 'chip selected' : 'chip'} onClick={() => setSide(s)}>
                {s === 'buy' ? 'Buy' : 'Sell'}
              </button>
            ))}
          </span>
        )}
        {symbols && list.length === 0 && <span className="muted">Nothing saved yet</span>}
      </div>

      <header className="price">
        <div className="label">{shown?.label ?? (symbol ? symbolTitle(category, symbol) : '')}</div>
        <div className="value">
          {point ? (
            <>
              {formatValue(point.v)} <span className="unit">{shown?.unit}</span>
            </>
          ) : (
            '—'
          )}
        </div>
        <div className="change">
          {point && change !== null && (
            <strong style={{ color: changeColor(change) }}>
              {signed(change)} ({signed(pct ?? 0, 2)}%)
            </strong>
          )}
          {point && shown && (
            <span className="muted">{active !== null ? pointTime(point, shown) : sinceText(shown.range, shown.intraday)}</span>
          )}
        </div>
      </header>

      <section className="chart" aria-busy={loading}>
        {loading && shown && <div className="bar" />}
        {error && !shown ? (
          <div className="center">
            <p className="error">{error}</p>
            <button className="retry" onClick={() => setReload((n) => n + 1)}>
              Retry
            </button>
          </div>
        ) : !shown ? (
          <div className="center">
            <div className="spinner" aria-label="Loading" />
          </div>
        ) : shown.points.length === 0 ? (
          <div className="center muted">No prices saved for this period yet</div>
        ) : (
          <PriceChart chart={shown} color={changeColor(shown.change)} onActive={setActive} />
        )}
      </section>

      <div className="ranges" role="group" aria-label="Period">
        {RANGES.map((r) => (
          <button key={r.id} className={r.id === range ? 'range selected' : 'range'} onClick={() => setRange(r.id)}>
            {r.title}
          </button>
        ))}
      </div>

      <footer className="muted small">
        {sourceText(category)}
        {error && shown && <div className="error">{error}</div>}
      </footer>
    </main>
  );
}
