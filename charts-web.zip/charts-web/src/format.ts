import type { Category, ChartData, ChartPoint, RangeCode } from './api';

const two = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const four = new Intl.NumberFormat('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 });

/** 6,122.58 — small values (like the yen, 0.3360) get 4 decimals. */
export function formatValue(v: number): string {
  return Math.abs(v) < 1 ? four.format(v) : two.format(v);
}

/** +1.71 / −232.54 */
export function signed(v: number, decimals?: number): string {
  const body =
    decimals === undefined
      ? formatValue(Math.abs(v))
      : Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (v >= 0 ? '+' : '−') + body;
}

/** Times from the API are Cairo time without a zone; show them as they are. */
function parse(p: ChartPoint): Date {
  return new Date(p.t);
}

/** Labels under the chart. */
export function axisTime(p: ChartPoint, chart: ChartData): string {
  const d = parse(p);
  if (chart.intraday) return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (chart.range === '6M' || chart.range === '1Y') return d.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

/** The pointed-at point's time, in the header. */
export function pointTime(p: ChartPoint, chart: ChartData): string {
  const d = parse(p);
  const day = d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: chart.intraday ? undefined : 'numeric' });
  return chart.intraday ? `${day}, ${d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` : day;
}

export function sinceText(range: RangeCode, intraday: boolean): string {
  switch (range) {
    case '1D':
      return intraday ? 'since yesterday' : 'vs. previous day';
    case '1W':
      return 'past week';
    case '1M':
      return 'past month';
    case '6M':
      return 'past 6 months';
    case '1Y':
      return 'past year';
  }
}

export function symbolTitle(category: Category, symbol: string): string {
  if (category === 'gold') return symbol === 'pound' ? 'Gold pound' : `${symbol}K`;
  if (category === 'stock') return symbol.replace(/\.CA$/, '');
  return symbol;
}

export function sourceText(category: Category): string {
  switch (category) {
    case 'stock':
      return 'Stock prices: TradingView (EGX)';
    case 'gold':
    case 'silver':
      return 'World price (gold-api.com) × CBE dollar rate, EGP per gram';
    case 'fx':
      return 'Exchange rates: Central Bank of Egypt via AllRatesToday (allratestoday.com)';
  }
}
