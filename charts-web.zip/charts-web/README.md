# Finance charts (React + TypeScript)

A web page with tabs **Stocks / Gold / Silver / Currency**, a button for each stock, karat, grade or
currency, the price and its change, a line chart, and **Day / Week / Month / 6M / Year**. Move the
mouse (or a finger on a touch screen) over the chart to see the price at any point. It reads the
backend's `/api/chart` API. Screenshots are in `screenshots/`.

## Just use it

You don't need this folder for that: the finished page is already inside the backend. Start the
backend and open **http://localhost:8080**.

## Change the code

Needs Node.js 18 or newer (`node -v`). Put this folder next to the `backend` folder:

```
finance-backend/
  backend/
  charts-web/
```

Install once:

```bash
npm install
```

While the backend runs, start the page with live reload:

```bash
npm run dev
```

and open http://localhost:5173. Every change you save in `src/` shows up at once.
(`npm run dev` sends `/api/...` on to the backend at http://localhost:8080.)

When you are happy, put the new version into the backend:

```bash
npm run build:backend
```

This writes the page to `../backend/src/main/resources/static/`. Restart the backend and
http://localhost:8080 shows the new version.

## Files

| File | What it does |
|---|---|
| `src/api.ts` | Calls `/api/chart` and `/api/chart/symbols`; the TypeScript types of the answers |
| `src/App.tsx` | The page: tabs, buttons, price header, loading and error states |
| `src/PriceChart.tsx` | The chart (Recharts) |
| `src/format.ts` | Number and date formatting, labels |
| `src/styles.css` | Look, with light and dark mode |

To use a backend on another computer, create a file `.env.local` with
`VITE_API_URL=http://192.168.1.20:8080` (that computer's address), then run `npm run dev` again.
