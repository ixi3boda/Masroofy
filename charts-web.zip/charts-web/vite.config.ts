import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// `npm run dev` serves the app on http://localhost:5173 and passes /api/... to the backend,
// so the backend must be running on http://localhost:8080.
export default defineConfig({
  plugins: [react()],
  build: { chunkSizeWarningLimit: 800 },
  server: {
    proxy: { '/api': 'http://localhost:8080' },
  },
});
